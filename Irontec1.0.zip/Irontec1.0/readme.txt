=== Irontec ===
Contributors: Jose A. Garrido
Stable tag: 1.0
Tested up to: 4.8
Requires at least: 4.6

Esto es una demo de plugin para Irontec.

== Description ==

En esta demos solo se muestra una frase y es para mostrar como se instala desde COMPOSER.